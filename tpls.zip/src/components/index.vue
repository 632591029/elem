<template>
  <div class="">
    
  </div>
</template>

<script>
export default {
  name: 'index',
  data () {
    return {
     
    }
  }
}
</script>

<style >

</style>
