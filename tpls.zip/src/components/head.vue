<template>
  <div class="head">
   	<div class="head-content">
   		<div class="avatar">
   			<img src="../assets/img/bgstore.jpg">
   			<span></span>
   		</div>
   		<div class="alltitle">
   			<span class="logo"></span>
   			<span class="title">{{seller.name}}</span><br>
   			<span class="subtitle">{{seller.description}}/{{seller.deliveryTime}}分钟送达</span><br>
   			<span class="logo2"></span><span class="rule">{{seller.supports[0].description}}</span>
   			<span class="num" @click="showdetail">{{seller.supports.length}}个&gt;</span>
   		</div>
   	</div>
   	<div class="foot" @click="showdetail" >
   		<span class="img"></span>
   		<i class="gti">&gt;</i>
   		<span>{{seller.bulletin}}</span>
   	</div>
   	<div class="background">
   		<img src="../assets/img/bgstore2.jpg">
   	</div>
   	<transition name="fade" class="detail" >
  		<div class="detail-inside" v-show="isdetail" @click="showdetail" >
  			<div class="name">{{seller.name}}</div>
  			<div class="star-list">
  				<star :size="48" :score="seller.score"></star>	
  			</div>
  			<div class="msg">	
  				<div class="line"></div>
  				<div class="text">优惠信息</div>
  				<div class="line"></div>
  			</div>
  			<div class="yh_detail">
  				<ul>
  					<li v-for="(items,index) in seller.supports">
  						<span class="icons" :class="bgtype[items.type]"></span>
  						<span class="text">{{items.description}}</span>
  					</li>
  				</ul>
  			</div>
  			<div class="msg">	
  				<div class="line"></div>
  				<div class="text">商家公告</div>
  				<div class="line"></div>
  			</div>
  			<div class="gg_detail">
  				<span class="text">{{seller.bulletin}}</span>
  			</div>
  			<div class="close">
  				X
  			</div>
  		</div>
    </transition>	
  </div>
  
</template>

<script>
import star from './star.vue'
export default {
  name: 'head',
  props:{
  	seller:{
  		type:Object
  	}
  },
  
  data () {
    return {
     isdetail:false,
     bgtype:[]
    }
  },
  methods:{
  	showdetail(){
  		if(this.isdetail==true){
  			this.isdetail=false;
  		}else{
  			this.isdetail=true;
  		}
  		
  		
  	}
  },
  created(){
  	this.bgtype=['jian','zhe','te','piao','bao']
  },
  components:{
  	star:star
  }

}
</script>

<style lang="scss" scoped>
	$y:100%;
	.head{
		color: #fff;
		width: $y;
		height: 135px;
		background-color: rgba(7,17,27,0.5);
		position: relative;
		.head-content{
			width: $y;
			height: $y;
			padding:25px;
			
		}
		.background{
			width: $y;
			height: $y;    
			position: absolute;
		    top: 0;
		    left: 0;
		    width: $y;
		    height: $y;
		    z-index: -1;
		    filter: blur(10px);
		    img{
		    	width: $y;
				height: $y; 
		    }
		}
		.avatar {
			width: 64px;height: 64px;display: inline-block;
			margin-right: 10px;
			img{
				width: $y;
				height: $y; 
				vertical-align: baseline;
			}
		}
		.alltitle{
			display:inline-block;
			line-height: 18px;
    		font-size: 12px;
    		width:70%;
			.logo{
				width: 30px;
				height: 18px;
				display: inline-block;
				background-image: url('../assets/img/brand@2x.png');
				background-size: $y $y;
				line-height: 20px;
				margin-right: 15px
			}
			.title{
				font-size: 16px;
			    line-height: 18px;
			    font-weight: bold;
			}
			.logo2{
				width: 12px;height: 12px;display: inline-block;
				background-image: url('../assets/img/decrease_1@2x.png');
				background-size: $y $y;margin-right: 10px;
			}
			.num{
				font-size: 10px;
	    		vertical-align: top;
	    		display: inline-block;float: right;
	    		width: 35px;height: 24px;background: rgba(0,0,0,0.2);
	    		border-radius: 12px;line-height: 24px;text-align: center;
			}
		}
		.foot{
			position: absolute;
			bottom: 0;
			width: 100%;
			box-sizing:border-box;
			background-color: rgba(7,17,27,0.2);
		    height: 28px;
		    line-height: 28px;
		    padding: 0 22px 0 12px;
		    // padding-right: 30px;
		    white-space: normal;
		    overflow: hidden;
		    text-overflow: ellipsis;
		    span{
		    	vertical-align: top;
			    margin: 0 4px;
			    font-size: 10px;
		    }
		    .img{
		    	display: inline-block;
		    	width: 20px;
		    	height: 15px;
		    	vertical-align: top;    margin-top: 5px;
		    	background-image: url('../assets/img/bulletin@2x.png');
		    	background-size: $y $y
		    }
		    .gti{
		    	font-size:18px;line-height:18px;
		    	position: absolute;
		    	right:8px;
		    	top:4px;
		    }
		}
	}
	.detail-inside{
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background: rgba(7,17,27,0.8);
		z-index: 1000;
		padding-top: 80px;
		text-align: center;
		&.fade-enter-active{
			animation:bounceIn .5s;
		}
		&.fade-leave-active{
			animation:bounceOut .5s;	
		}
		@keyframes bounceIn{
			0%{
				transform:scale(0);
			}
			50%{
				transform:scale(1.5);
			}
			100%{
				transform:scale(1);
			}
		}
		@keyframes bounceOut{
			0%{
				transform:scale(1);
			}
			50%{
				transform:scale(1.5);
			}
			100%{
				transform:scale(0);
			}
		}
		.name{
			margin-bottom: 20px;
		}
		.msg{
			display: flex;
			margin: 20px auto 20px auto;
			padding: 0 30px;
			.line{
				position: relative;
				top:-9px;
				flex:1;
    			border-bottom: 1px solid rgba(255,255,255,0.2);
			}
			.text{
				padding: 0 10px;
			}
		}
		.yh_detail{
			padding: 0 50px;
			text-align: left;
			li{
				padding: 3px 0 ;
			}
			.text{
				display: inline-block;
			    line-height: 12px;
			    font-size: 12px;
			    color: #fff;
			}
			.icons{
				vertical-align: middle;
				font-size: 0;
				display: inline-block;
				width: 18px;
				height: 18px;
				background-size: 18px 18px;
				margin-right: 10px;
				&.jian{
					background-image: url('../assets/img/header/decrease_2@2x.png');
				}
				&.zhe{
					background-image: url('../assets/img/header/discount_2@2x.png');
				}
				&.te{
					background-image: url('../assets/img/header/special_2@2x.png');
				}
				&.piao{
					background-image: url('../assets/img/header/invoice_2@2x.png');
				}
				&.bao{
					background-image: url('../assets/img/header/guarantee_2@2x.png');
				}
			}
		}
		.gg_detail{
			text-align: left;
			padding: 0 50px;
			line-height: 24px;
    		font-size: 12px;
		}
		.close{
			width: 50px;
			height: 50px;
			font-size: 20px;
			position: absolute;
			bottom: 20px;
			left: 50%;
			margin-left: -25px;
		}
	}

</style>
