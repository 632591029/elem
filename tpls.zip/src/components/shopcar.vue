<template>
	<div>
		
	
	<div class="shopcar">
		<div  @click="check" style="height:48px;width:100%;z-index:30;background: #141d27;">
			<div class="cartLogo">
				<div class="insidelogo">
					<i class="fa fa-cart-plus" aria-hidden="true"></i>
					<div class="nums"  v-show="allcount>0">
						<span>{{allcount}}</span>
					</div>
				</div>
			</div>
			<div class="price">
				<span :class="{'money':allPrice>0}" >¥{{allPrice}}</span>
			</div>
			<div class="send">
				<span>另需配送费4元</span>
			</div>
		</div>
	
		<div class="pay" :class="{'canPay' : allPrice>=20}" @click="fnPay">
			<span>{{allPrice<20?(allPrice==0?'¥20元起送':'还差¥'+ Cmoney +'元起送'):'去结算'}}</span>
		</div>
		<transition name="fade">
			<div class="content list" v-show="checkCart">
			  <div class="list-header">
	            <h1 class="title">购物车</h1>
	            <span class="empty" @click="empty" >清空</span>
	          </div>
	          <div class="list-content" ref="listContent">
	            <ul>
	              <li class="shopcart-food" v-for="food in food" v-show="food.count>0">
	                <span class="content-name">{{food.name}}</span>
	                <div class="content-price">
	                	<span>￥{{food.price * food.count}}</span>
	                </div>
	                <div class="cartCtrol">
	                	<cartCtrol :food="food"></cartCtrol>
	                </div>
	                
	              </li>
	            </ul>
	          </div>
			</div>
		</transition>
	</div>
	<transition name="fade">
			<div class="background" v-show="background">
					
			</div>
	</transition>
	</div>
</template>
<script type="text/javascript">
import cartCtrol from './cartCtrol.vue';
import BScroll from 'better-scroll';
	export default{
		data(){
			return{
				price:0,
				Cmoney:"",
				allmoney:'',
				checkCart:false,
				background:false
			}
		},
		props:{
			food:{
				type:Array
			}
		},
		computed:{
			allPrice(){
				let money=0;let notMoney;

					this.food.forEach((food)=>{
						money+= food.count*food.price;
					})
				notMoney = 20-money;
				this.Cmoney =notMoney
				this.allmoney = money;
				return  money;

			},
			allcount(){
				let count=0;

					this.food.forEach((food)=>{
						count+= food.count;
					})
				return  count;
			}
		},
		methods:{
			fnPay(){
				if(this.allmoney>=20){
					alert(this.allmoney+'元')
				}	
			},
			check(){
				if(this.checkCart==false && this.allmoney>0){
					this.checkCart=true;
					this.background=true;
					this.$nextTick(() => {
						if (!this.scroll) {
			              this.scroll = new BScroll(this.$refs.listContent, {
			                click: true
			              });
			            } else {
			              this.scroll.refresh();
			            }
					});
					
				}else{
					this.background=false;
					this.checkCart=false;
				}
			},
			empty(){
		        this.food.forEach((food) => {
		          food.count = 0;
		        });
		        this.background=false;
				this.checkCart=false;
			}
		},
		updated(){
			let counts=0;
			this.food.forEach((food) => {
		          counts+=food.count;
		    });
		    if(counts>0){
		    	
		    }else{
		    	this.background=false;
				this.checkCart=false;
		    }
		},
		components:{
			cartCtrol:cartCtrol
		}
	}
</script>
<style  lang="scss" scoped>
	.shopcar{
	    position: fixed;
	    left: 0px;
	    bottom: 0px;
	    z-index: 50;
	    width: 100%;
	    height: 48px;	
	    .list{
	    	position: absolute;
	    	top:0;
	    	left:0;
	    	width: 100%;
	    	transform :translate3d(0, -100%, 0);
	    	z-index: -111;
	    	&.fade-enter-active,&.fade-leave-active{
	    		transition:all 0.5s;
	    		transform:translate3d(0, -100%, 0);
	    	}
	    	&.fade-enter,&.fade-leave-active{
	    		transform:translate3d(0, 0, 0);
	    	}
	    	.list-header{
    		    height: 40px;
			    line-height: 40px;
			    padding: 0 18px;
			    background: #f3f5f7;
			    border-bottom: 1px solid rgba(7,17,27,0.1);
			    .title{
			    	float: left;
			    	font-size: 14px;
				    color: #07111b;
			    }
			    .empty{
			    	float: right;
		    	    font-size: 12px;
   				    color: #00a0dc;
			    }
	    	}
	    	.list-content{
    		    padding: 0 18px;
			    max-height: 217px;
			    overflow: hidden;
			    background: #fff;
	    		position: relative;
	    		.shopcart-food {
	    			position: relative;
	    			padding:12px 0 ;
	    			&:after{
	    				display: block;
					    position: absolute;
					    left: 0;
					    bottom: 0;
					    border-top: 1px solid rgba(7,17,27,0.1);
					    width: 100%;
					    content: '';
	    			}
	    			.content-price{
	    				position: absolute;
	    				right: 70px;
	    				top:13px;
	    				color:red;
	    			}
	    			.content-name{
    				    line-height: 24px;
					    font-size: 14px;
					    color: #07111b;
	    			}
	    		}
	    		.cartCtrol{
	    			position: absolute;
	    			right: 5px;
	    			top:13px;
	    			color: #00a0dc;
	    		}
	    	}
	    }
	    .cartLogo{
	    	background: #141d27;
	    	border-radius: 50%;
	    	text-align: center;
	    	line-height: 58px;
	    	width: 60px;
	    	height: 58px;
	    	position: absolute;
	    	top:-10px;
	    	left: 20px;
	    	font-size: 30px;
	    	color: 	#80858a;
	    	.insidelogo{
	    		position: absolute;
	    		top:5px;
	    		left:5px;
	    		width: 50px;
	    		height: 50px;
	    		line-height: 50px;
	    		border-radius: 50%;
	    		background: #2b343c;
	    		.nums{
	    			position: absolute;
	    			top:-6px;
	    			right:-4px;
	    			border-radius: 50%;
	    			width: 20px;
	    			height: 20px;
	    			font-size: 14px;
	    			text-align: center;
	    			color:#fff;
	    			line-height: 20px;
	    			background: red;
	    		}
	    	}
	    }
	    .price{
	    	box-sizing:border-box;
	    	width: 65px;
	    	height: 38px;
	    	top:5px;
	    	position: absolute;
	    	left: 80px;
	    	text-align:center;
	    	line-height:38px;
	    	border-right: 1px solid rgba(255,255,255,0.1);
		    font-size: 16px;
		    font-weight: 700;
		    color: rgba(255,255,255,0.4);
		    span.money{
		    	color:#fff;
		    }
	    }
	    .send{
	    	color: rgba(255,255,255,0.4);
	    	width: 100px;
	    	height: 100%;
	    	line-height: 48px;
	    	font-size: 10px;
	    	position: absolute;
	    	left:160px;
	    }
	    .pay{
	    	position: absolute;
	    	right: 0px;
    		padding: 0 20px;
	    	height: 48px;
	    	top: 0;
		    line-height: 48px;
		    text-align: center;
		    font-size: 12px;
		    color: rgba(255,255,255,0.4);
		    font-weight: 700;
		    z-index: 40;
		    &.canPay{
		    	background:#00b43c;
		    	color:#fff;
		    }
	    }
	   
	}
	 .background{
	    	background:rgba(7,17,27,0.6);
	    	position: fixed;
		    top: 0;
		    left: 0;
		    width: 100%;
		    height: 100%;
		    z-index: 40;
		    opacity: 1;

		      &.fade-enter-active, &.fade-leave-active {
			    transition: all 0.5s;
			    background: rgba(7, 17, 27, 0.6);
			  }
			  &.fade-enter, &.fade-leave-active {
			    opacity: 0;
			    background: rgba(7, 17, 27, 0);
			  }
	}
</style>