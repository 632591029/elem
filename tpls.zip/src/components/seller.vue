<template>
	<div class="seller" ref="seller">
		<div class="main">
			<div class="head-1th clear">
				<div class="head-1th-left">
					<h1>{{seller.name}}</h1>
					<star :size="36" :score="seller.score" class="star"></star>
					<span class="num">({{seller.ratingCount}})</span>
					<span class="sellCount">月售{{seller.sellCount}}单</span>
				</div>
				<div class="coll" @click="coll">
					<i class="fa fa-heart" aria-hidden="true" :class="{'colled':colled}"></i> <br>
					<span>收藏</span>
				</div>
			</div>
			<ul class="head-2th clear">
				<li class="min">
					<p>起送价</p>
					<span>{{seller.minPrice}}</span>元
				</li>
				<li class="del">
					<p>商家配送</p>
					<span>{{seller.deliveryPrice}}</span>元
				</li>
				<li class="time">
					<p>平均配送时间</p>
					<span>{{seller.deliveryTime}}</span>
				</li>
			</ul>
			<div class="kong"></div>
			<div class="act">
				<h1>公告与活动</h1>
				<p>{{seller.bulletin}}</p>
				<ul v-if="seller.supports" class="supports">
		          <li class="support-item" v-for="(item, index) in seller.supports">
		            <span class="icon" :class="classMap[seller.supports[index].type]" ></span>
		            <span class="text">{{seller.supports[index].description}}</span>
		          </li>
		        </ul>
			</div>
			<div class="kong"></div>
			<div class="store">
				<h1>商家实景</h1>
				<div class="pic-wrapper" ref="picWrapper">
		          <ul class="pic-list clear" ref="picList">
		            <li class="pic-item" v-for="pic in seller.pics">
		              <img :src="pic" width="120" height="120">
		            </li>
		          </ul>
		        </div>
			</div>
			<div class="msg">
				<h1>商家信息</h1>
				<ul>
		          <li class="info-item" v-for="info in seller.infos">{{info}}</li>
		        </ul>
			</div>
		</div>
	</div>
</template>
<script type="text/javascript">
  import star from './star.vue';
  import BScroll from 'better-scroll';
	export default{
		data(){
			return {
				colled:false
			}
		},
		props: {
	      seller: {
	        type: Object
	      }
	    },
	    components:{
	    	star:star
	    },
	    methods:{
	    	coll(){
	    		if(this.colled){
	    			this.colled=false;
	    		}else{
					this.colled=true;
	    		}
	    	}
	    },
	    created(){
	    	 if (!this.picScroll) {
		        if (this.seller.pics) {
		          this.$nextTick(() => {
		            let picWidth = 120;
		            let margin = 6;
		            let width = (picWidth + margin) * this.seller.pics.length ;
		            this.$refs.picList.style.width = width + 'px';
		            this.picScroll = new BScroll(this.$refs.picWrapper, {
		              scrollX: true,
		              eventPassthrough: 'vertical'
		            });
		          });
		        }
		      } else {
		        this.picScroll.refresh();
		      }
	    	this.$nextTick(() => {
		        this.scroll = new BScroll(this.$refs.seller, {click: true});
		    });
		    this.classMap = ['decrease', 'discount', 'special', 'invoice', 'guarantee'];
	    }
	}
</script>
<style lang="scss" scoped>
	.seller{
		  width: 100%;
		  position: absolute;
		  top: 174px;
		  bottom: 0;
		  overflow :hidden;
		.main{
			.msg{
				padding:20px 20px;
				h1{
					margin-bottom: 10px;
				}
				li{	
					border-top: 1px solid rgba(7,17,27,0.1);
				    padding: 16px 12px;
				    line-height: 16px;
				    position: relative;
				    font-size: 12px;
				}
			}
			.act{
				padding:15px 20px;
				p{
				   line-height: 24px;
				}
				h1{
					margin-bottom: 8px;
				    line-height: 14px;
				    color: #07111b;
				    font-size: 14px;
				}
				.supports{
					.icon{
						display: inline-block;
						width: 20px;
						height: 20px;
						background-size: 100% 100%;
						vertical-align: top;
			          &.decrease{
			          		background-image: url('../assets/img/header/jian.png');
			          }
			           
			          &.discount{
			          	background-image: url('../assets/img/header/zhe.png');
			          }
			            
			          &.guarantee{
			          	background-image: url('../assets/img/header/te.png');
			          }
			            
			          &.invoice{
			          	background-image: url('../assets/img/header/piao.png');
			          }
			            
			          &.special{
			          	background-image: url('../assets/img/header/bao.png');
			          }
			            
					}
					li{
						padding: 16px 12px;
    					position: relative;
    					border-bottom: 1px solid rgba(7,17,27,0.1);
    					.text{
    						font-size: 12px;
						    line-height: 16px;
						    color: #07111b;
    					}
					}
					
				}
			}
			.store{
				padding: 20px 20px;
				h1{
					margin-bottom:10px;
				}
				.pic-list{
					li{
						float: left;
						margin-right: 6px;
			            width: 120px;
			            height:90px;
			            img{
			            	width: 100%;
			            	height: 100%;
			            }
					}
				}
				.pic-wrapper{
					width: 100%;
					overflow: hidden;
					white-space: nowrap;
				}
			}
			.head-1th{
				padding:15px 20px;
				padding-bottom: 20px;
				border-bottom: 1px solid rgba(7,17,27,0.1);
			}
			.head-1th-left{
				float: left;
				h1{
					margin-bottom: 8px;
				    line-height: 14px;
				    color: #07111b;
				    font-size: 14px;
				}
				.num{
					font-size: 12px;
					vertical-align: top;
				}
				.star{
					display: inline-block;
					vertical-align: top;
				}
				.sellCount{
				    vertical-align: top;
				    margin-right: 12px;
				    line-height: 18px;
				    font-size: 10px;
				    color: #4d555d;
				}
			}
			.coll{
				font-size: 17px;
				text-align: center;
				float: right;
				i{
					font-size: 20px;
					color:#d4d6d9;
					&.colled{
						color:red;
					}
				}
			}
			.head-2th{
				padding:20px 20px;
				width: 100%;
				li{
					float: left;
					width: 33.3%;
					box-sizing:border-box;
					text-align: center;font-size: 12px;
					padding:15px 0;
					&:not(:last-child){
						border-right: 1px solid rgba(7,17,27,0.1);
					}
					&.min,&.time,&.del{
						p{
							margin-bottom: 4px;
						    line-height: 10px;
						    font-size: 10px;
						    color: #939995;
						}
						span{
							line-height: 24px;
						    font-size: 24px;
						    color: #07111b
						}
					}
				}
			}	
			.kong{
				width: 100%;
			    height: 16px;
			    border-top: 1px solid rgba(1,17,27,0.1);
			    background: #f3f5f7;
			}
		}
	}
</style>