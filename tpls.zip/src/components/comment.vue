<template>
	<div class="comment" ref="list">
		<div class="main" >
			<ul class="clear">
				<li class="fn-score">
					<h1 class="num">4.2</h1>
					<span class="subtitle">综合评分</span><br>
					<span class="nexttitle">高于周边商家69.2%</span>
				</li>
				<li class="scores">
					  <div class="score-wrapper">
			            <span class="title">服务态度</span>
			            <star :size="36" :score="seller.serviceScore" class="star"></star>
			            <span class="score">{{seller.serviceScore}}</span>
			          </div>
			          <div class="score-wrapper">
			            <span class="title">商品评分</span>
			            <star :size="36" :score="seller.foodScore" class="star"></star>
			            <span class="score">{{seller.foodScore}}</span>
			          </div>
			          <div class="delivery-wrapper">
			            <span class="title">送达时间</span>
			            <span class="delivery">{{seller.deliveryTime}}分钟</span>
			          </div>
				</li>
			</ul>
			<div class="kong"></div>
			<div class="comment-content">
				<evaluate :ratings="ratings"  :select-type="selectType" :hasContent="hasContent" @switchContent="updateContent" class="commentvue">
					
				</evaluate>
				<div class="all-ratings clear" >
					<ul v-show="ratings && ratings.length" class="clear">
		              <li v-for="rating in ratings"  class="clear"   v-show="isShowContent(rating.text,rating.rateType)">
		              	<div class="avatar">
		              		<img width="12" height="12" :src=rating.avatar alt="" >
		              	</div>
		                <div class="user-content">
		                  <span >{{rating.username}}</span>
		                  <div class="star-wrapper">
			                <star :size="24" :score="rating.score"></star>

			              </div>
			              <p class="text">
			                  {{rating.text}}
		                  </p>
		                  <i class="fa" aria-hidden="true" :class="{'fa-thumbs-up':rating.rateType===0,'fa-thumbs-down':rating.rateType===1}" ></i>
		                   <span  class="item" v-for="item in rating.recommend" >{{item}}</span>
		                </div>
		                <div class="time">{{rating.rateTime | formatDate}}</div>
		                
		              </li>
		            </ul>
				</div>
			</div>
		</div>
	</div>
</template>
<script type="text/javascript">
import star from './star.vue';
import BScroll from 'better-scroll';
import evaluate from './evaluate.vue';
import data  from '../data.json';
import {formatDate} from '../assets/js/date.js';
const ALL=2;
	export default{
		components:{
			star:star,
			evaluate:evaluate
		},
		filters: {
	      formatDate(time) {
	        let date = new Date(time);
	        return formatDate(date, 'yyyy-MM-dd hh:mm');
	      }
	    },	
		props: {
	      seller: {
	        type: Object
	      }
	    },
	    created(){
	    	this.ratings=data.ratings;
	    	this.$nextTick(() => {
		        this.scroll = new BScroll(this.$refs.list, {click: true});
		    });
	    },
	    data(){
	    	return{
	    		 ratings: [],
	    		 selectType:ALL,
	    		 hasContent:true,
	    	}
	    },
	    methods:{
			updateContent(type,data){
				  this[type]=data;
				  this.$nextTick(() => {
		          this.scroll.refresh();
		        });
			},
			isShowContent(text,type){
				if(this.hasContent && !text){
					return false;
				}
				if(this.selectType===ALL){
					 return true;
				}else{
					return type===this.selectType;
				}
			}
	    }
	}
</script>
<style lang="scss" scoped>
	.comment{
		  position: absolute;
		  top: 174px;
		  bottom: 0;
		  overflow :hidden;
		.main{	
			ul{
				padding:20px 0;
			}
			li{
				float: left;
				box-sizing:border-box;
				text-align: center;
			}
			.num{
				margin-bottom: 12px;
			    line-height: 28px;
			    font-size: 24px;
			    color: #f90;
			}
			.fn-score{
				padding:8px 0;
				padding-left: 10px;
				width: 40%;
				border-right: 1px solid rgba(7,17,27,0.1);
			}
			.subtitle{
			    line-height: 12px;
			    font-size: 12px;
			    color: #07111b;
			}
			.nexttitle{
			    line-height: 10px;
			    font-size: 12px;
			    color: #93999f;
			}
			.scores{
				width: 60%;
				text-align: left;
				.score-wrapper{
					padding:5px 30px;
				}
				.delivery-wrapper{
					padding:5px 30px;
				}
				.star{
					display: inline-block;
				}
				.title{
				    display: inline-block;
				    vertical-align: top;
				    line-height: 18px;
				    font-size: 12px;
				    color: #07111b;
				}
				.score{
				    display: inline-block;
				    vertical-align: top;
				    line-height: 18px;
				    font-size: 12px;
				    color: #f90;
				}
				.delivery{
				    display: inline-block;
				    margin-left: 12px;
				    vertical-align: top;
				    line-height: 18px;
				    font-size: 12px;
				    color: #93999f;
				}
			}
			.kong{
				width: 100%;
			    height: 16px;
			    border-top: 1px solid rgba(1,17,27,0.1);
			    background: #f3f5f7;
			}
		}
		.comment-content{
			.commentvue{
					padding:10px 15px;
				}
			ul{
				padding:0 10px;
			}
			li{
				text-align: left;
				position: relative;
				width: 100%;
				padding:20px 10px;
				&:after{
					display: block;
				    position: absolute;
				    left: 0;
				    bottom: 0;
				    border-top: 1px solid rgba(1,17,27,0.1);
				    width: 100%;
				    content: '';
				}
				.avatar{
					float: left;height: 100%;
					width: 10%;text-align: right;
					img{
						border-radius: 50%;
						width: 30px;
						height: 30px;
					}
				}
				.user-content{
					float: left;
					width: 90%;
					margin-bottom: 4px;
				    line-height: 12px;
				    font-weight: 700;
				    font-size: 10px;
				    color: #07111b;
				    .text{
			    	    line-height: 18px;
					    color: #07111b;
					    font-size: 12px;
					    margin-bottom: 8px;
					    font-weight: normal;
				    }
				    .item{
			    	    padding: 0 6px;
					    border: 1px solid rgba(7,17,27,0.1);
					    border-radius: 1px;
					    color: #93999f;
				    }
				    .fa-thumbs-up{
		    			color: #00a0dc;
		    		}
				}
				.time{
					position: absolute;
					top:20px;right: 0;
				    line-height: 12px;
				    font-size: 10px;
				    color: #93999f;
				}

			}
		}
	}
</style>