<template>
	<div class="goods">
		<div class="menu-wrap"  ref="menuWrapper">
			<ul>
				<li  v-for="(item, index) in goods" class="menu-item" @click="selectMenu(index, $event)"   :class="{'chose':currentIndex === index}">
					<span>
		            	<span v-show="item.type>0"></span>
		            	{{item.name}}
		            </span>
				</li>
			</ul>
		</div>
		<div class="food-wrap"  ref="foodWrapper">
			<ul>
				<li v-for="(item,index) in goods" class="lists">
					<h1 class="title">{{item.name}}</h1>
					<ul>
						<li v-for="food in item.foods"  class="food-item"  @click="selectFoods(food, $event)">
							<div class="icon">
			                	<img :src="food.icon" alt="" width="57">
			                </div>
			                <div class="content">
				                <h2 class="name">{{food.name}}</h2>
				                <p class="desc">{{food.description}}</p>
				                <div class="extra">
				                  <span class="count">月售{{food.sellCount}}</span><span class="count">好评{{food.rating}}</span>
				                </div>
				                <div class="price">
				                  <span class="now">￥{{food.price}}</span><span class="old"
				                                                                v-show="food.oldPrice">￥{{food.oldPrice}}</span>
				                </div>
				                <div class="cartCtrol">
				                	 <!-- <i class="fa fa-plus-square" aria-hidden="true" @click="addcar"></i> -->
				                	 <cartCtrol :food="food" @toShopCar="toDropCar"></cartCtrol>
				                </div>
				               
				            </div>

						</li>
						
					</ul>
				</li>
			</ul>
		</div>
		<food ref="food" :food="selectFood" @foodtoshopCar="toDropCar"></food>
		<shopcar ref="shopcar" :food="addfood"></shopcar>
	</div>
</template>
<script type="text/javascript">
	import data from '../data.json';
	import BScroll from 'better-scroll';
	import food from './food.vue';
	import cartCtrol from './cartCtrol.vue';
	import shopcar from './shopcar.vue';
	export default{
		data(){
			return{
				goods:[],
				scrolly:0,
				listHeight:[],
				selectFood:{},
				addfood:[]
			}
		},
		created(){
			this.goods=data.goods;
			this.$nextTick(() => {
		        this._initScroll();
		        this._calculateHeight();
		    });
		},
		methods:{
			_initScroll(){
				this.scroll=new BScroll(this.$refs.menuWrapper,{
					click:true
				});
				this.scroll2=new BScroll(this.$refs.foodWrapper,{
					click:true,
					probeType:3
				});
				this.scroll2.on('scroll',(pos)=>{
					this.scrolly=Math.abs(Math.round(pos.y));
				});
			},
			_calculateHeight() {
		        let foodList = this.$refs.foodWrapper.getElementsByClassName('lists');
		        let height = 0;
		        this.listHeight.push(height);
		        for (let i = 0; i < foodList.length; i++) {
		          let item = foodList[i];
		          height += item.clientHeight;
		          this.listHeight.push(height);
		       }

		    },
			selectMenu(index, event){
				 if (!event._constructed) {
		          return;
		        }
		        let foodList = this.$refs.foodWrapper.getElementsByClassName('lists');
		        let el = foodList[index];
		        this.scroll2.scrollToElement(el, 300);
			},
			selectFoods(food,e){
				if (!event._constructed) {
		          return;
		        }
				this.selectFood=food;;
				this.$refs.food.show();
			},
			toDropCar(food){
				this.addfood=[];
				this.goods.forEach((good) => {
			          good.foods.forEach((food) => {
			            if (food.count) {
			              this.addfood.push(food);
			            }
			          });
			        });
			}
		},
		computed:{
			currentIndex(){

				for (let i = 0; i < this.listHeight.length; i++) {
		          let height = this.listHeight[i];
		          let height2 = this.listHeight[i + 1];
		          if (!height2 || (this.scrolly >= height && this.scrolly < height2)) {
		            return i;
		          }
		        }
				return 0;
			}
		},
		components:{
			food:food,
			cartCtrol:cartCtrol,
			shopcar:shopcar
		}
	}
</script>
<style lang="scss" scoped>
// .clear{ clear:both; height:0px; width:0px; overflow:hidden;}
	.goods{
		width: 100%;
		display: flex;
		position: absolute;
		bottom:46px;
		top:177px;
		overflow: hidden;
		.menu-wrap{
			flex:0 0 80px;
    		width: 80px;
    		background: #f3f5f7;
    		height: 100%;
    		.menu-item{
				display:table; 
			    height: 54px;
			    line-height: 14px;
			    padding: 0 12px;
			    font-size: 12px;
			    width: 80px;
			    text-align: center;
			    span{
			    	display: table-cell;
			    	vertical-align: middle;
			    	border-bottom:1px solid #ccc;
			    }
			 }
			 .chose{
			  	background-color: #fff;
			  }
		}
		.food-wrap{
			height: 100%;	
			flex:1;
			.title{
			    padding-left: 14px;
			    height: 26px;
			    line-height: 26px;
			    border-left: 2px solid #d9dde1;
			    font-size: 12px;
			    color: #93999f;
			    background: #f3f5f7;
			}
			ul li.food-item{
			    margin: 18px;
			    margin-bottom: 18px;
			    position: relative;
			    display: flex;
			    padding-bottom: 15px;
			    border-bottom: 1px solid rgba(7,17,27,0.1);
			    .icon{
			    	flex: 0 0 57px;
			    	margin-right: 15px;
			    }
			    .content{
					flex: 1;
					position: relative;
					.name{
						margin: 2px 0 8px 0;
					    font-size: 14px;
					    line-height: 14px;
					    height: 14px;
					    color: #07111b;
					}
					.desc,.extra{
					    font-size: 10px;
					    line-height: 10px;
					    color: #93999f;
					    margin-bottom: 10px;
					}
					.price{
					    margin-right: 8px;
					    font-size: 14px;
					    color: #f01414;

					}
					.cartCtrol{
						height: 24px;
					    display: inline-block;
					    line-height: 24px;
					    font-size: 24px;
					    vertical-align: top;
					    color: #00a0dc;
					    position: absolute;
					    bottom: 0;right: 0
					}
			    }
			}
		}
		
	}
</style>