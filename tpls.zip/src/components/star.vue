<template>
	<div class="star">
		<div class="star-item" :class="starType">
			<span v-for="items in starScore" :class="items" class="items"></span>
		</div>
	</div>
</template>
<script type="text/javascript">
  const LENGTH = 5;
  const ON = 'on';
  const HALF = 'half';
  const OFF = 'off';
	export default{
		props:{
			score:{
				type:Number
			},
			size:{
				type:Number
			}
		},
		computed:{
			starType(){
				return 'star-'+this.size;
			},
			starScore(){
				let result=[];
				let score = Math.floor(this.score * 2)/2;
				let isDE = score % 1 !== 0;
				let int = Math.floor(score);
				for(let i=0;i<score;i++){
					result.push(ON);
				}
				if(isDE){
					result.push(HALF);
				}
				while (result.length < LENGTH) {
		          result.push(OFF);
		        }
		        return result;
			}
		}
	}
</script>
<style lang="scss" scoped>
	.star{
		font-size: 0px;
		.star-item{
			display: inline-block;
			background-repeat: no-repeat;
			&.star-48{
				.items{
					display: inline-block;
					width: 20px;
					height: 20px;
					margin-right: 22px;
					background-size: 20px 20px;
					&:last-child{
						 margin-right: 0;
					}
					&.on{
						background-image: url('../assets/img/star/star48_on@2x.png');
					}
					&.half{
						background-image: url('../assets/img/star/star48_half@2x.png');
					}
					&.off{
						background-image: url('../assets/img/star/star48_off@2x.png');
					}
				}
			}
			&.star-36{
				.items{
					display: inline-block;
					width: 15px;
					height: 15px;
					margin-right: 3px;
					background-size: 15px 15px;
					&:last-child{
						 margin-right: 0;
					}
					&.on{
						background-image: url('../assets/img/star/star36_on@2x.png');
					}
					&.half{
						background-image: url('../assets/img/star/star36_half@2x.png');
					}
					&.off{
						background-image: url('../assets/img/star/star36_off@2x.png');
					}
				}
			}
			&.star-24{
				.items{
					display: inline-block;
					width: 10px;
					height: 10px;
					margin-right: 3px;
					background-size: 10px 10px;
					&:last-child{
						 margin-right: 0;
					}
					&.on{
						background-image: url('../assets/img/star/star24_on@2x.png');
					}
					&.half{
						background-image: url('../assets/img/star/star24_half@2x.png');
					}
					&.off{
						background-image: url('../assets/img/star/star24_off@2x.png');
					}
				}
			}
		}
	}
</style>