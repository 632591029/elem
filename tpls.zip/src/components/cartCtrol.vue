<template>
	<div class="cartCtrol-main">
		<transition name="fade">
	        <div class="cart-decrease" v-show="food.count>0" @click.stop.prevent="decreaseCar($event)">
	          <transition name="inner" >
	          <i class="fa fa-minus" aria-hidden="true"></i>
	          </transition>
	        </div>
	    </transition>
	     <span class="cart-count inner" v-show="food.count>0">
	      {{food.count}}
	    </span>

		<i class="fa fa-plus-square" aria-hidden="true" @click.stop.prevent="addcar($event)"></i>

	</div>
</template>
<script type="text/javascript">
import Vue from 'vue';
	export default{
		props:{
			food:{
				type:Object
			}
		},
		methods:{
			addcar(e){
				if (!e._constructed) {
		          return;
		        }
				if(!this.food.count){
					Vue.set(this.food,'count',1);
				}else{
					this.food.count++;
				}
				this.$emit('toShopCar',this.food);
			},
			decreaseCar(e){
				if (!e._constructed) {
		          return;
		        }
				this.food.count--;
				this.$emit('toShopCar',this.food);
			}
		}

	}
</script>
<style lang="scss" scoped>
	.cartCtrol-main{
		.cart-decrease{
			display: inline-block;
			opacity: 1;
			&.fade-enter-active, &.fade-leave-active {
		      transition: all 0.4s linear;
		    }
		    &.fade-enter, &.fade-leave-active {
		      opacity: 0;
		      transform :translate3d(24px, 0, 0);
		    }
		}
		.inner{
		    	color: #000;
		    	font-size: 14px;
		    	opacity: 0.8;
		      &.inner-enter-active, &.inner-leave-active {
		        transition: all 0.4s linear;
		        transform: rotate(0)
		      }
		      &.inner-enter, &.inner-leave-active {
		        opacity: 0;
		        transform : rotate(180deg);
		      }
		    }
	}
</style>