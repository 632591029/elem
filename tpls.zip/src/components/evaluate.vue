<template>
	<div class="evaluate">
		<div class="type">
			<span class="positive" @click="chose(2,$event)" :class="{'active':selectType==2}">
				{{desc.all}}&nbsp;{{ratings.length}}
			</span>
			<span class="positive" @click="chose(0,$event)" :class="{'active':selectType==0}">
				{{desc.positive}}&nbsp;{{positives.length}}
			</span>
			<span class="negative"  @click="chose(1,$event)" :class="{'active':selectType==1}">
				{{desc.negative}}&nbsp;{{nagatives.length}}
			</span>
		</div>	
		<div class="switchon" @click="switchi" >
			<i class="fa fa-check-circle" aria-hidden="true":class="{'has':hasContent}"></i>
			<span style="font-size: 12px;">只看有内容的评价</span>
		</div>
	</div>
</template>
<script type="text/javascript">
		const POSITIVE = 0;
		const NEGATIVE = 1;
		const ALL = 2;
	export default{
		props:{
			ratings: {
		        type: Array,
		        default() {
		          return [];
		        }
		      },
			desc:{
				type:Object,
				default(){
					return {
					  all: '全部',
		              positive: '满意',
		              negative: '吐槽'
					}
				}
			},
			selectType:{
				type:Number,
				deafult:ALL
			},
			hasContent:{
				type:Boolean,
				default:false
			}
		},
		computed: {
	      positives() {
	        return this.ratings.filter((rating) => {
	          return rating.rateType === POSITIVE;
	        });
	      },
	      nagatives() {
	        return this.ratings.filter((rating) => {
	          return rating.rateType === NEGATIVE;
	        });
	      }
	    },
		methods:{
			chose(type,e){
				if (!event._constructed) {
		          return;
		        }
		        this.selectType=type;
		        this.$emit('switchContent', 'selectType', this.selectType); 
			},
			switchi(){
				if (!event._constructed) {
		          return;
		        }
				this.hasContent=!this.hasContent;
				this.$emit('switchContent', 'hasContent', this.hasContent);
			}
		}
	}
</script>
<style lang="scss" scoped>
	.evaluate{
		.type{
		    position: relative;
		    font-size: 0;
		    span{
		    	display: inline-block;
		    	text-align: center;
		    	width: 50px;
		    	height: 35px;
		    	line-height: 35px;
			    margin-right: 8px;
			    border-radius: 1px;
			    font-size: 12px;
			    color: #4d555d;
			    &.positive{
			    	background: rgba(0, 160, 220, 0.2);
			    	&.active{
			    		color: #ffffff;
          				background :rgb(0, 160, 220);
			    	}
			    }
			    &.negative{
			    	 background: rgba(77, 85, 93, 0.2);
			    	 &.active{
			    	    color :#ffffff;
			            background :rgb(77, 85, 93);
			    	 }
			    }
		    }
		}
		.switchon{
			color: #93999f;
			font-size: 0;
			line-height: 24px;
			i{
				font-size:24px;vertical-align:top;
				&.has{
					color:#00c850;
				}
			}
			span,i{
				display: inline-block;
				margin-top: 20px;
			}
		}
	}
</style>