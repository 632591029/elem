<template>
	<transition name="fade">
		<div v-show="isChose" class="food">
			<div class="content">
				<div class="food-head">
					<img :src="food.image">
				</div>
				<div class="back" @click="back">
					&lt;
				</div>
				<div class="midmsg">
					<h2>{{food.name}}</h2>
					<span class="midword">月售{{food.sellCount}}</span><span class="midword">好评率{{food.rating}}%</span>
					<div class="price">
						<span>¥{{food.price}}</span><button @click.stop.prevent="addCar($event)" v-show="isadd">加入购物车</button>
						<div class="cartCtrol-main" v-show="!isadd">
							<transition name="fade">
						        <div class="cart-decrease" v-show="food.count>0" @click.stop.prevent="decreaseCar($event)">
						          <transition name="inner" >
						          <i class="fa fa-minus" aria-hidden="true"></i>
						          </transition>
						        </div>
						    </transition>
						     <span class="cart-count inner" v-show="food.count>0">
						      {{food.count}}
						    </span>
							<i class="fa fa-plus-square" aria-hidden="true" @click.stop.prevent="addcar($event)"></i>
						</div>
					</div>
				</div>
				<div class="kong" v-show="food.info"></div>
				<div class="detail" v-show="food.info">
					<h2>商品信息</h2>
					<span>{{food.info}}</span>
				</div>
				<div class="kong"></div>
				<div class="allping">
					<h1>商品评价</h1>
					<evaluate :ratings="food.ratings" :desc="desc"  :select-type="selectType" :hasContent="hasContent" @switchContent="updateContent"></evaluate>
					<ul v-show="food.ratings && food.ratings.length">
		              <li v-for="rating in food.ratings" v-show="isShowContent(rating.text,rating.rateType)">
		                <div class="user">
		                  <span >{{rating.username}}</span>
		                  <img width="12" height="12" :src=rating.avatar alt="" >
		                </div>
		                <div class="time">{{rating.rateTime | formatDate}}</div>
		                <p class="text">
		                  <i class="fa" aria-hidden="true" :class="{'fa-thumbs-up':rating.rateType===0,'fa-thumbs-down':rating.rateType===1}" ></i>
		                  {{rating.text}}
		                </p>
		              </li>
		            </ul>
				</div>
			</div>

			
		</div>
	</transition>
</template>
<script type="text/javascript">	
	import Vue from 'vue';
	import data from '../data.json';
	import BScroll from 'better-scroll';
	import evaluate from './evaluate.vue';
	import {formatDate} from '../assets/js/date.js';
	const ALL = 2;
	export default {
		props:{
			food:{
				type:Object
			}
		},
		filters: {
	      formatDate(time) {
	        let date = new Date(time);
	        return formatDate(date, 'yyyy-MM-dd hh:mm');
	      }
	    },
		data(){
			return{
				isChose:false,
				desc: {
		          all: '全部',
		          positive: '推荐',
		          negative: '吐槽'
		        },
		        selectType:ALL,
		        hasContent:true,
		        isadd:true
			}
		},
		methods:{
			show(){
				this.isChose=true;
				this.$nextTick(()=>{
					if(!this.scroll){
					this.scroll = new BScroll(this.$el,{
							click:true
					});
					}else{
						this.scroll.refresh();
					}
				})
				
			},
			back(){
				this.isChose=false
			},
			updateContent(type,data){
				  this[type]=data;
				  this.$nextTick(() => {
		          this.scroll.refresh();
		        });
			},
			isShowContent(text,type){

				if(this.hasContent && !text){
					return false;
				}
				if(this.selectType===ALL){
					 return true;
				}else{
					return type===this.selectType;
				}
			},
			addCar(e){
				this.isadd=false;
				Vue.set(this.food,'count',1);
				this.$emit('foodtoshopCar',this.food);
			},
			addcar(e){
				if(!e._constructed){
					return;
				}
				if(!this.food.count){
					Vue.set(this.food,'count',1);
				}else{
					this.food.count++;
				}
				this.$emit('foodtoshopCar',this.food);
			},
			decreaseCar(e){
				if(!e._constructed){
					return;
				}
				if(this.food.count==1){
					this.food.count--;
					this.isadd=true;
				}else{
					this.food.count--;
				}
				this.$emit('foodtoshopCar',this.food);
			}	
		},
		components:{
			evaluate:evaluate
		}


	}
</script>
<style lang="scss" scoped>
	.food{
		position: fixed;
		top:0;
		left: 0;
		bottom: 48px;
		z-index: 30;
		width: 100%;
		background:#fff;
		&.fade-enter-active, &.fade-leave-active {
	      transition: all 0.2s linear;
	      transform :translate3d(0, 0, 0)
	    }
	    &.fade-enter, &.fade-leave-active {
		   opacity: 0;
		   transform: translate3d(100%, 0, 0)
		}

	    .food-head{
	    	position: relative;
	    	padding-top: 100%;
	    	img{
	    		position: absolute;
   				top: 0;
	    		width: 100%;
	    		height:100%;
	    	}
	    }
	    .back{
	    	font-size: 30px;
	    	color:#fff;
	    	position: absolute;
	    	top:10px;
	    	left:10px;
	    }
	    .midmsg{
	    	padding: 20px;
	    	h2{
    		    line-height: 14px;
			    margin-bottom: 8px;
			    font-size: 14px;
			    font-weight: 700;
			    color: #07111b;
	    	}
	    	.midword{
	    		font-size: 10px;
			    display: inline-block;
			    color: #93999f;
	    	}
	    	.price{
	    		color: red;
	    	}
	    	button{
	    		float: right;    
			    height: 24px;
			    line-height: 24px;
			    padding: 0 12px;
			    box-sizing: border-box;
			    border-radius: 12px;
			    font-size: 10px;
			    color: #fff;
			    background: #00a0dc;
	    	}
	    }
	    .kong{
	    	width: 100%;
		    height: 16px;
		    border-top: 1px solid rgba(1,17,27,0.1);
		    background: #f3f5f7;
	    }
	    .detail{
	    	padding: 20px;
	    	h2{
	    		margin-bottom: 10px;
	    	}
	    	span{
	    		font-size: 12px;
			    line-height: 24px;
			    padding: 0 8px;
			    color: #4d555d;
	    	}
	    }
	    .allping{
	    	padding: 20px;
	    	.evaluate{
		    	    padding: 20px 0;
		    }
		    ul li{
		    	position: relative;
		    	padding:10px 0;
		    	.user{
		    		position: absolute;
		    		top:0;right:0;margin-bottom: 6px;
		    		line-height: 12px;
				    font-size: 10px;
				    color: #93999f;
		    	}
		    	.time{
		    		margin-bottom: 6px;
				    line-height: 12px;
				    font-size: 10px;
				    color: #93999f;
		    	}
		    	.text{
		    		line-height: 16px;
				    font-size: 12px;
				    color: #07111b;
		    		.fa-thumbs-up{
		    			color: #00a0dc;
		    		}
		    	}
		    }
	    }
		.cartCtrol-main{
			display: inline-block;
			float: right;
			 color: #00a0dc;
			     font-size: 22px;
			.cart-decrease{
				display: inline-block;
				opacity: 1;
				&.fade-enter-active, &.fade-leave-active {
			      transition: all 0.4s linear;
			    }
			    &.fade-enter, &.fade-leave-active {
			      opacity: 0;
			      transform :translate3d(24px, 0, 0);
			    }
			}
			.inner{
			    	color: #000;
			    	font-size: 14px;
			    	opacity: 0.8;
			      &.inner-enter-active, &.inner-leave-active {
			        transition: all 0.4s linear;
			        transform: rotate(0)
			      }
			      &.inner-enter, &.inner-leave-active {
			        opacity: 0;
			        transform : rotate(180deg);
			      }
			    }
		}
	}
</style>