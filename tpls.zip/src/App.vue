<template>
  <div id="app">
    <v-header :seller="seller"></v-header>

    <div class="tab border-1px">
      <div class="tab-item" @click="choose">
        <router-link to="/goods"  :class="{ 'on': isOn1 }">
          商品

        </router-link>

      </div>
      <div class="tab-item" @click="choose2">
        <router-link to="/comment" :class="{ 'on': isOn2 }">
          评论
        </router-link>
      </div>
      <div class="tab-item" @click="choose3">
        <router-link to="/seller" :class="{ 'on': isOn3 }" >
          商家
        </router-link>
      </div>
    </div>

    <router-view :seller="seller"></router-view>

    <shopcar> </shopcar> 
  </div>
</template>

<script>
 import data from './data.json';
 import header from './components/head.vue';
 import shopcar from './components/shopcar.vue';

export default {
 data() {
      return {
        seller: {},
        isOn1:true,
        isOn2:false,
        isOn3:false
      };
    },
  components:{
    'v-header':header,
    'shopcar':shopcar
  },
  created(){
    this.seller = data.seller;
  },
  methods:{
    choose(){
      this.isOn1=true;
      this.isOn2=false;
      this.isOn3=false;
    },
     choose2(){
      this.isOn1=false;
      this.isOn2=true;
      this.isOn3=false;
    },
     choose3(){
      this.isOn1=false;
      this.isOn2=false;
      this.isOn3=true;
    }
  },
  name: 'app'
}
</script>

<style>
      body,div,p,ul,ol,li,dl,dt,dd,h1,h2,h3,h4,h5,h6,table,tr,td,form,input,select,textarea,span,img,a,em,strong,*{ margin:0; padding:0; }
body{ font:16px "Microsoft YaHei", Arial, Helvetica, sans-serif;overflow-x: hidden;background: #ffff;}
*{
  box-sizing: border-box;
}

ul,ol,li{ list-style:none;}
h1,h2,h3,h4,h5,h6{ font-size:16px; font-weight:normal;}
input,select,textarea{ vertical-align:middle;font-family:"Microsoft YaHei", Arial, Helvetica, sans-serif;}
img{ border:none; vertical-align:middle;}
a{ text-decoration:none;color: #4d555d;}
em,i{font-style: normal;}
.clear:after{
  content: "";
  display: block;
  clear: both;
}
b{ font-weight:normal;}
input{outline-style:none;}
button{
  border:none;
}
 button:focus,button:active:focus,button.active:focus,button.focus,button:active.focus,button.active.focus {    outline: none;    border-color: transparent;    box-shadow:none;}

.border-1px{
   border: 1px solid rgba(7,17,27,0.1); 
}
.tab{
  width: 100%;
}
.tab-item{
  width: 32%;
  display:inline-block;
  height: 40px;    font-size: 14px;
  text-align: center;
  line-height: 40px;
}
.tab-item a{
  width: 100%;height: 100%;
  display: inline-block;
  color: #7e8c8d;
}
.tab-item a.on{
  width: 100%;height: 100%;
  display: inline-block;color: red;
}

</style>
