import Vue from 'vue'
import Router from 'vue-router'
import VueResource from 'vue-resource'


import index from '@/components/index';
import goods from '@/components/goods';
import comment from '@/components/comment';
import seller from '@/components/seller';
Vue.use(VueResource)
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      component: goods
    },
    {
      path: '/goods',
      component: goods   
    },
    {
      path: '/comment',
      component: comment
    },
    {
      path: '/seller',
      component: seller
    },
  ]
})
